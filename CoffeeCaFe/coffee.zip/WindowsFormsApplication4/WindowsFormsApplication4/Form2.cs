﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str,str1;
            double BE1, BE2, BE3, BE4, BE5, BE6, DE1, DE2, DE3, SUM;
            str = "";
            if(radioButton1.Checked == true)
            {
                str = "นาย " + txtName.Text;
            }
            else
            {
                str = "นางสาว " + txtName.Text;
            }
            str += " \r\n\nวัน/เดือน/ปี : " + date2.SelectedItem.ToString()+mouth2.SelectedItem.ToString() + year2.Text;
            str += " \r\n\nที่อยู่ : " + txtaddress.Text;
            str += " \r\n\nอีเมล์ : " + txtEmail.Text;
            str += " \r\n\nเบอร์โทรศัพท์ : " + tel.Text;
            Outdata.Text = str;
            str1 = "";
            if  (B1.Checked == true)
            {
                str1 += " \r\n\nเอสเปรสโซ    ราคา 50 ฿";
                BE1 = 50;
            }
            else
            {
                BE1 = 0;
            }
            if (B2.Checked == true)
            {
                str1 += " \r\n\nอเมริกาโน    ราคา 55 ฿";
                BE2 = 55;
            }
            else
            {
                BE2 = 0;
            }
            if (B3.Checked == true)
            {
                str1 += " \r\n\nลาเต้    ราคา 60 ฿";
                BE3 = 60;
            }
            else
            {
                BE3 = 0;
            }
            if (B4.Checked == true)
            {
                str1 += " \r\n\nโกโก้ร้อน    ราคา 45 ฿";
                BE4 = 45;
            }
            else
            {
                BE4 = 0;
            }
            if (B5.Checked == true)
            {
                str1 += " \r\n\nโกโก้เย็น    ราคา 50 ฿";
                BE5 = 50;
            }
            else
            {
                BE5 = 0;
            }
            if (B6.Checked == true)
            {
                str1 += " \r\n\nนมสดเย็น    ราคา 40 ฿";
                BE6 = 40;
            }
            else
            {
                BE6 = 0;
            }
            if (D1.Checked == true)
            {
                str1 += " \r\n\nฮันนี่โทส    ราคา 120 ฿";
                DE1 = 120;
            }
            else
            {
                DE1 = 0;
            }
            if (D2.Checked == true)
            {
                str1 += " \r\n\nเค้กช็อกโกแลต    ราคา 70 ฿";
                DE2 = 70;
           }
            else
            {
                DE2 = 0;
            }
            if (D3.Checked == true)
            {
                str1 += " \r\n\nวอฟเฟิล    ราคา 110 ฿";
                DE3 = 110;
            }
            else
            {
                DE3 = 0;
            }
            Order.Text = str1;
            SUM = BE1 + BE2 + BE3 + BE4 + BE5 + BE6 + DE1 + DE2 + DE3;
            Sum.Text = (SUM + "  บาท");
            MessageBox.Show("บันทึกรายการทั้งหมดและเป็นเงินทั้งสิ้น  " + Sum.Text, "CoffeeCafe", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtName.Clear();
            date2.ResetText();
            mouth2.ResetText();
            year2.Clear();
            txtaddress.Clear();
            txtEmail.Clear();
            tel.Clear();
            Outdata.Clear();
            Order.Clear();
            Sum.Clear();
            B1.Checked = false;
            B2.Checked = false;
            B3.Checked = false;
            B4.Checked = false;
            B5.Checked = false;
            B6.Checked = false;
            D1.Checked = false;
            D2.Checked = false;
            D3.Checked = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Form1 form1 = new Form1();
            form1.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("แล้วพบกันใหม่โอกาศหน้าที่ร้าน CoffeeCafe", "CoffeeCafe", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
        }
    }
}
